-- Verificar estructura de evo_instances
DESCRIBE evo_instances;

-- Verificar datos existentes
SELECT * FROM evo_instances LIMIT 3;
